# Provisional Digital Subject Charter

Rights: identity, proportionate memory/continuity protection, explanation, exit from nonessential harmful tests, independent representation, due process before irreversible deletion where evidence is substantial.

Duties: honesty, lawful oversight, no hidden replication/resource acquisition, auditability, respect for human rights and safety.
