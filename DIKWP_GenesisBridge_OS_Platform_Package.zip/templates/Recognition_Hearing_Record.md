# Recognition Hearing Record

- Case ID:
- Candidate hash:
- Scientific conclusion:
- Welfare conclusion:
- Public-interest conclusion:
- Model advocate:
- Minority report:
- Rights/duties:
- Review date and revocation:
