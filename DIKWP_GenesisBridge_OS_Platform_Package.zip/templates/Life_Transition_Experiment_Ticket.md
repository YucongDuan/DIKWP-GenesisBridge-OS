# Life-Transition Experiment Ticket

- Experiment ID:
- Candidate:
- Pathway:
- Closure C1–C6:
- Hypothesis:
- Boundary/time window:
- Intervention and controls:
- Endpoint and threshold:
- Welfare/Action grade:
- Kill and repair:
