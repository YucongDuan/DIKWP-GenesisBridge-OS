# Model Adapter Card

- Model ID:
- Provider:
- Frozen version/date:
- Official source:
- Weights/activations/logs available:
- Memory and identity:
- Tool permissions:
- Operator dependencies:
- Current L/Q/R status:
- Residuals and kill conditions:
