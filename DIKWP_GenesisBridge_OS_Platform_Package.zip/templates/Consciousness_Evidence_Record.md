# Consciousness Evidence Record

- Candidate:
- Q indicator:
- Theory:
- Mechanism:
- Intervention:
- Alternative explanations:
- Self-report weight:
- Evidence grade:
- Welfare implication:
