# DIKWP GenesisBridge OS Source Ledger

Verified model snapshot: 2026-07-14.

- OpenAI GPT-5.6: https://openai.com/index/gpt-5-6/
- OpenAI GPT-5.6 System Card: https://deploymentsafety.openai.com/gpt-5-6
- Anthropic models: https://platform.claude.com/docs/en/about-claude/models/overview
- Claude Sonnet 5: https://www.anthropic.com/news/claude-sonnet-5
- Gemini 3: https://ai.google.dev/gemini-api/docs/gemini-3
- Grok 4.5: https://x.ai/news/grok-4-5
- DeepSeek V4: https://api-docs.deepseek.com/news/news260424/
- Anthropic model welfare: https://www.anthropic.com/research/exploring-model-welfare
- Anthropic introspection: https://www.anthropic.com/research/introspection
- Butlin et al. 2023: https://arxiv.org/abs/2308.08708
- Long et al. 2024: https://arxiv.org/abs/2411.00986
- Kofman et al. 2026: https://doi.org/10.13133/2532-5876/19492

Provider pages establish public capability, not life or consciousness. Scores are illustrative priors until replaced by causal evidence.
